const getUsers = (req, res) => {
    res.json({ message: 'List of users will be returned here' });
};

const addUser = (req, res) => {
    const newUser = req.body; 
    res.status(201).json({ message: 'User added', user: newUser });
};

module.exports = { getUsers, addUser }; // Ensure this line is present
