//define the logic for fetching and adding products.

const Product = require('../models/Product');

// Fetch all products
const getProducts = async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// Add a new product
const addProduct = async (req, res) => {
    const { name, price, description, category, stock, imageUrl } = req.body;
    try {
        const newProduct = new Product({
            name, price, description, category, stock, imageUrl
        });
        const savedProduct = await newProduct.save();
        res.status(201).json(savedProduct);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

module.exports = { getProducts, addProduct };
