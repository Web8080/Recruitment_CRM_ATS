const express = require('express');
const cors = require('cors'); // Import the CORS middleware
const { Pool } = require('pg'); // Import pg library
const userRoutes = require('./routes/userRoutes'); // Ensure this path is correct

const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // To parse JSON bodies

// PostgreSQL connection
const pool = new Pool({
    user: 'postgres', // Replace with your database username
    host: 'localhost',
    database: 'ecommerce_db', // Replace with your database name
    password: 'NTU99999@', // Replace with your database password
    port: 5432, // Default PostgreSQL port
});

// API endpoint to get products
app.get('/api/products', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM products');
        res.json(result.rows); // Send the products as JSON
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Failed to fetch products' });
    }
});

// New API endpoint to get categories
app.get('/api/categories', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM categories'); // Adjust based on your database
        res.json(result.rows); // Send categories as JSON
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
});

// Use the user routes
app.use('/api/users', userRoutes); // Ensure this is correct

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
