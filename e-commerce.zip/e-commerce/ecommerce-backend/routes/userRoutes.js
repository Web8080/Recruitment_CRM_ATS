// routes/userRoutes.js
const express = require('express');
const router = express.Router();

// This should be your user data storage. Replace this with your database logic.
let users = []; // In-memory array to store users for this example

// POST /api/users - Add a new user
router.post('/', (req, res) => {
    const { name, email } = req.body; // Destructure the incoming data

    // Simple validation to check if both fields are present
    if (!name || !email) {
        return res.status(400).json({ message: "Name and email are required." });
    }

    // Create a new user object
    const newUser = {
        id: users.length + 1, // Simple ID assignment, replace this with your DB logic
        name,
        email,
    };

    // Simulating saving the user to the database
    users.push(newUser); // Add user to the in-memory array (for example purposes)

    // Respond with the new user data
    res.status(201).json({
        message: "User added",
        user: newUser, // Return the added user object
    });
});

// GET /api/users - Retrieve all users
router.get('/', (req, res) => {
    res.json(users); // Return the array of users
});

module.exports = router;
