const products = [
    {
        id: 1,
        name: 'Product 1',
        price: 29.99,
        image: 'e-commerce-frontend/public/images/product1.jpg', // Image path relative to the public folder
        description: 'Description of Product 1',
        category_id: 1,
    },
    {
        id: 2,
        name: 'Product 2',
        price: 49.99,
        image: '/images/product2.jpeg', // Image path relative to the public folder
        description: 'Description of Product 2',
        category_id: 2,
    },
    // Add more products as needed
];

export default products;
