// src/pages/Login.js

import React from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation
import './Login.css'; // Create a CSS file for styling

const Login = () => {
    return (
        <div className="login-page">
            <h1>Login</h1>
            <form>
                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input type="email" id="email" placeholder="Enter your email" required />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password:</label>
                    <input type="password" id="password" placeholder="Enter your password" required />
                </div>
                <button type="submit">Login</button>
            </form>
            <div className="login-footer">
                <p>Don't have an account? <Link to="/signup">Register here</Link></p> {/* Updated to use Link */}
                <p><Link to="/forgot-password">Forgot Password?</Link></p> {/* Updated to use Link */}
            </div>
            
        </div>
    );
};

export default Login;
