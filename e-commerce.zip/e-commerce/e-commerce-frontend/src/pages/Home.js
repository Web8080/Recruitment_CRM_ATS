// src/pages/Home.js

import React, { useEffect, useState } from 'react';
import Product from '../components/Product';
import CategoryDropdown from '../components/CategoryDropdown';
import { fetchProducts, fetchCategories } from '../services/api'; // Import API functions
import '../styles/App.css'; // Import global CSS file
import './Home.css'; // Import Home-specific styles

const Home = () => {
    const [products, setProducts] = useState([]); // Store fetched products
    const [categories, setCategories] = useState([]); // Store fetched categories
    const [selectedCategory, setSelectedCategory] = useState(''); // Store selected category
    const [loading, setLoading] = useState(true); // Loading state for products
    const [error, setError] = useState(''); // Error state for API calls

    useEffect(() => {
        const loadProducts = async () => {
            try {
                const productsData = await fetchProducts();
                console.log('Fetched Products:', productsData); // Log the products data

                if (Array.isArray(productsData)) {
                    setProducts(productsData);
                } else {
                    setError('Invalid data format for products.');
                }
            } catch (error) {
                console.error('Error loading products:', error);
                setError('Failed to load products. Please try again later.');
            } finally {
                setLoading(false); // Stop loading after fetch
            }
        };

        const loadCategories = async () => {
            try {
                const categoriesData = await fetchCategories();
                console.log('Fetched Categories:', categoriesData); // Log the categories data

                if (Array.isArray(categoriesData)) {
                    setCategories(categoriesData);
                } else {
                    setError('Invalid data format for categories.');
                }
            } catch (error) {
                console.error('Error loading categories:', error);
                setError('Failed to load categories. Please try again later.');
            }
        };

        loadProducts();
        loadCategories();
    }, []);

    const handleCategorySelect = (categoryId) => {
        setSelectedCategory(categoryId);
    };

    // Filter products by the selected category
    const filteredProducts = selectedCategory
        ? products.filter((product) => product.category_id === Number(selectedCategory))
        : products;

    // Get featured products
    const featuredProducts = products.filter((product) => product.is_featured);

    return (
        <div className="home-page">
            <h1>Welcome to Our Store</h1>

            {/* Promotional Banner */}
            <div className="hero-banner">
                <img src="/images/banner.webp" alt="Promotional Banner" />
            </div>

            {/* Special Promotion Section */}
            <div className="promotional-banner">
                <h2>Special Promotion</h2>
                <p>Get 20% off on your first purchase!</p>
                <img src="/images/promo2.jpeg" alt="Special Promotion" />
            </div>

            {/* Category Dropdown */}
            <CategoryDropdown categories={categories} onSelect={handleCategorySelect} />

            {/* Featured Products Section */}
            <h2>Featured Products</h2>
            {loading ? (
                <p>Loading featured products...</p>
            ) : error ? (
                <p>{error}</p>
            ) : (
                <div className="product-grid">
                    {featuredProducts.length > 0 ? (
                        featuredProducts.map((product) => (
                            <Product key={product.id} product={product} />
                        ))
                    ) : (
                        <p>No featured products available.</p>
                    )}
                </div>
            )}

            {/* Product List Section */}
            <h2>Product List</h2>
            <div className="filters">
                <label htmlFor="category">Category:</label>
                <select id="category" onChange={(e) => handleCategorySelect(e.target.value)}>
                    <option value="">All</option>
                    {categories.map((category) => (
                        <option key={category.id} value={category.id}>{category.name}</option>
                    ))}
                </select>

                <label htmlFor="sort">Sort by:</label>
                <select id="sort">
                    <option value="popular">Most Popular</option>
                    <option value="low-to-high">Price: Low to High</option>
                    <option value="high-to-low">Price: High to Low</option>
                </select>
            </div>

            {/* Display Products */}
            {loading ? (
                <p>Loading products...</p>
            ) : error ? (
                <p>{error}</p>
            ) : (
                <div className="product-grid">
                    {filteredProducts.length > 0 ? (
                        filteredProducts.map((product) => (
                            <Product key={product.id} product={product} />
                        ))
                    ) : (
                        <p>No products available in this category.</p>
                    )}
                </div>
            )}
        </div>
    );
};

export default Home;
