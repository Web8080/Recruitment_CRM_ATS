// src/pages/About.js

import React from 'react';
import './About.css'; // Optional: create a separate CSS file for About page styling

const About = () => {
    return (
        <div className="about-page">
            <h1>About Us</h1>
            <p>
                Welcome to Our E-commerce Store! We are dedicated to providing our customers with the best online shopping experience.
                Our mission is to offer high-quality products at competitive prices.
            </p>
            <h2>Our Story</h2>
            <p>
                Founded in 2024, we started with a passion for great products and exceptional service. Over the years, we have grown
                into a trusted retailer, offering a wide range of products for every need.
            </p>
            <h2>Our Values</h2>
            <ul>
                <li>Quality: We believe in offering only the best products.</li>
                <li>Customer Satisfaction: Your satisfaction is our top priority.</li>
                <li>Innovation: We are always looking for new ways to improve.</li>
            </ul>
            
          
        </div>
    );
};

export default About;
