// src/pages/Cart.js

import React from 'react';
import './Cart.css'; // Create this file for styling

const Cart = () => {
    return (
        <div className="cart-page">
            <h1>Your Shopping Cart</h1>
            {/* You can later add logic to display cart items here */}
            <p>Your cart is currently empty.</p>
            {/* Add more cart functionality here, like listing items, total price, etc. */}
        </div>
    );
};

export default Cart;
