// src/pages/ForgotPassword.js

import React, { useState } from 'react';
import './PageStyles.css'; // Optional: Add your styles

const ForgotPassword = () => {
    const [email, setEmail] = useState('');

    const handlePasswordReset = (e) => {
        e.preventDefault();
        // Your password reset logic (API call, etc.)
        console.log("Password Reset Requested for", email);
    };

    return (
        <div className="page-container">
            <h1>Forgot Password</h1>
            <form onSubmit={handlePasswordReset}>
                <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <button type="submit">Reset Password</button>
            </form>
        </div>
    );
};

export default ForgotPassword;
