// src/pages/Contact.js

import React from 'react';
import './Contact.css'; // Optional: create a separate CSS file for Contact page styling

const Contact = () => {
    return (
        <div className="contact-page">
            <h1>Contact Us</h1>
            <p>If you have any questions or need assistance, feel free to reach out to us!</p>
            <h2>Get in Touch</h2>
            <p>Email: <a href="mailto:support@example.com">support@example.com</a></p>
            <p>Phone: <a href="tel:+11234567890">(123) 456-7890</a></p>
            <h2>Follow Us</h2>
            <div className="social-media-links">
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a>
            </div>
           
            
        </div>
    );
};

export default Contact;
