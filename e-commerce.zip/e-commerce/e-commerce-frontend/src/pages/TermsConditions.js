// src/pages/TermsConditions.js

import React from 'react';
import './PageStyles.css'; // Optional: Add your styles

const TermsConditions = () => {
    return (
        <div className="page-container">
            <h1>Terms & Conditions</h1>
            <p>Your terms and conditions content goes here...</p>
        </div>
    );
};

export default TermsConditions;
