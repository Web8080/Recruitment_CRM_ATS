// src/pages/Products.js

import React from 'react';
import ProductList from '../components/ProductList'; // Importing ProductList component
import './Products.css'; // Add any additional styling

const Products = () => {
    return (
        <div className="products-page">
            <h1>Products</h1>
            <ProductList /> {/* Rendering the product list */}
            
            <h2>Quick Links</h2>
            <ul>
                <li><a href="/about">About Us</a></li>
                <li><a href="/contact">Contact</a></li>
                <li><a href="/PrivacyPolicy">Privacy Policy</a></li>
                <li><a href="/TermsConditions">Terms & Conditions</a></li>
            </ul>
        </div>
    );
};

export default Products;
