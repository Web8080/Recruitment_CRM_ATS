// src/pages/PrivacyPolicy.js

import React from 'react';
import './PageStyles.css'; // Optional: Add your styles

const PrivacyPolicy = () => {
    return (
        <div className="page-container">
            <h1>Privacy Policy</h1>
            <p>Your privacy policy content goes here...</p>
        </div>
    );
};

export default PrivacyPolicy;
