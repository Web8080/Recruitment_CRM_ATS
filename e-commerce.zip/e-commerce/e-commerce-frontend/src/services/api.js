// src/services/api.js

const API_URL = 'http://localhost:5001/api'; // Adjust if necessary

// Using fetch to get products
export const fetchProducts = async () => {
    const response = await fetch(`${API_URL}/products`);
    if (!response.ok) {
        throw new Error('Failed to fetch products');
    }
    const data = await response.json();
    return data; // Ensure this matches your API response structure
};

// Using fetch to get categories (assuming you also want to implement this)
export const fetchCategories = async () => {
    const response = await fetch(`${API_URL}/categories`);
    if (!response.ok) {
        throw new Error('Failed to fetch categories');
    }
    const data = await response.json();
    return data; // Ensure this matches your API response structure
};
