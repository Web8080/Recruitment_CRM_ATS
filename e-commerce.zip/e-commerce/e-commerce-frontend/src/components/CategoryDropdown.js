// src/components/CategoryDropdown.js
import React from 'react';

const CategoryDropdown = ({ categories, onSelect }) => {
    return (
        <select onChange={(e) => onSelect(e.target.value)} defaultValue="">
            <option value="" disabled>Select Category</option>
            {categories.map(category => (
                <option key={category.id} value={category.id}>
                    {category.name}
                </option>
            ))}
        </select>
    );
};

export default CategoryDropdown;
