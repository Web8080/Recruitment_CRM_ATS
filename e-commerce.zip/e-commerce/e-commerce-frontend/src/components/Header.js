// src/components/Header.js

import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css'; // Make sure to style it in a separate CSS file

const Header = () => {
    return (
        <header className="header">
            <div className="logo">
                <Link to="/">Your Logo</Link>
            </div>
            <nav>
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/products">Products</Link></li>
                    <li><Link to="/about">About Us</Link></li>
                    <li><Link to="/contact">Contact</Link></li>
                </ul>
            </nav>
            <div className="search-cart">
                <input type="text" placeholder="Search products..." aria-label="Search" />
                <Link to="/cart" className="cart-icon">🛒 (0)</Link> {/* Make sure this is linked to /cart */}
                <Link to="/signup" className="sign-up">Sign Up</Link>
                <Link to="/login" className="user-account">Login</Link>
            </div>
        </header>
    );
};

export default Header;
