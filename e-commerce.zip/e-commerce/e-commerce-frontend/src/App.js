// src/App.js

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Products from './pages/Products';
import Login from './pages/Login';
import Footer from './components/Footer';
import Header from './components/Header';
import PrivacyPolicy from './pages/PrivacyPolicy'; // Import Privacy Policy
import TermsConditions from './pages/TermsConditions'; // Import Terms Conditions
import Signup from './pages/Signup'; 
import ForgotPassword from './pages/ForgotPassword'; 
import Cart from './pages/Cart'; 

const App = () => {
    return (
        <Router>
            <Header /> 
            <Routes> 
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/products" element={<Products />} />
                <Route path="/login" element={<Login />} />
                <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} /> 
                <Route path="/TermsConditions" element={<TermsConditions />} /> 
                <Route path="/signup" element={<Signup />} /> 
                <Route path="/forgot-password" element={<ForgotPassword />} /> 
                <Route path="/cart" element={<Cart />} />
            </Routes>
            <Footer />
        </Router>
    );
};

export default App;
